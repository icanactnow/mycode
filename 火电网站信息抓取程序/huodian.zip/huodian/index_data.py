datas = '''
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
    <meta http-equiv="x-ua-compatible" content="ie=7" />
    <title>火电-北极星火力发电网-专业的火电行业垂直门户网站</title>
    <meta name="keywords" content="火电,火力发电,火电项目,五大发电,火电产业,火电运行,火电技术,火电节能,火电环保,超低排放,脱硫脱硝,除灰除尘,热电联产,上大压小,生物质发电,燃气轮机,天然气发电" />
    <meta name="description" content="北极星火力发电网是专业的火电行业媒体，专注于火电产业新闻，火电项目审批，火电企业动态，超低排放、脱硫脱硝、除灰除尘技术，火电设备信息，火电行业研究，火电行业政策等信息的发布及展示。" />
    <link rel="shortcut icon" type="image/ico" href="http://img.mybjx.net/theme/default/images/common/favicon.ico" />
    <link href="http://img.mybjx.net/theme/default/css/subsite/subsite_public.css" rel="stylesheet"
        type="text/css" />
    <link href="http://img.mybjx.net/theme/default/css/subsite/topbar_public.css" rel="stylesheet"
        type="text/css" />
    <link href="http://img.mybjx.net/theme/default/css/subsite/subsite_default.css" rel="stylesheet"
        type="text/css" />
    <link href="http://img.mybjx.net/theme/default/css/subsite/subsite.css" rel="stylesheet"
        type="text/css" />
    <link href="/Content/Css/huodiancss/huodian.css?v=02032" rel="stylesheet" type="text/css" />
    
    <script src="http://img.mybjx.net/theme/default/js/common/jquery-1.6.min.js" type="text/javascript"></script>
    <script src="http://img.mybjx.net/theme/default/js/common/sohuflash_1.js" type="text/javascript"></script>
    <base target="_blank" />
</head>
<body>
    <div style="width: 980px; margin: 0 auto">
        <span id="kehusign_huodian_zd"></span>
    </div>
    <div class="xxhall">
<link href="http://img.mybjx.net/theme/default/css/subsite/huod_css_css.css?v=32" rel="stylesheet" type="text/css" />
<div class="xxhtop"><!--顶部-->
        <div class="xxhtopl"><a href="http://www.bjx.com.cn/">北极星电力网首页</a></div>
        <div class="fd_login"><script src="http://www.bjx.com.cn/GetLoginUser.asp" charset="gb2312"></script>
        <script src="http://www.bjx.com.cn/js/template_7.js" type="text/javascript" language="javascript" charset="gb2312"></script></div>
        <div class="xxhtop_y">
        <div class="xxhtop_r"><!--<a href="/" class="hylogin">会员请登陆</a>--><!--<a href="http://www.bjx.com.cn/denglu/denglu.html" class="adnewyh">注册新用户</a>--><a href="http://www.bjx.com.cn/about/baojia_index.html" class="float">广告投放</a> | </div>
        <div onmouseout="this.className='topr'" onmouseover="this.className='topron'" class="topr">北极星站群
        <div style="position:absolute;left:0; top:28px;width:100px; height:5px; background-color:#f9f9f9;z-index:1000; "></div>
<div class="nzq" id="zqlink">
                <ul>
                  <li class="nzqkuan">
                    <h6>行业站</h6>
                    <dl>
                        <dd><a href="http://huodian.bjx.com.cn" target="_blank">火力发电网</a></dd>
                        <dd><a href="http://huanbao.bjx.com.cn" target="_blank">环保网</a></dd>
                        <dd><a href="http://fd.bjx.com.cn" target="_blank">风力发电网</a></dd>
                        <dd><a href="http://guangfu.bjx.com.cn" target="_blank">光伏太阳能网</a></dd>
                        <dd><a href="http://shuidian.bjx.com.cn" target="_blank">水力发电网</a></dd>
                        <dd><a href="http://hedian.bjx.com.cn" target="_blank">核电网</a></dd>
                        <dd><a href="http://www.chinasmartgrid.com.cn" target="_blank">智能电网</a></dd>
                        <dd class="nzqred"><a href="http://shoudian.bjx.com.cn" target="_blank">售电网</a></dd>
                        <dd><a href="http://chuneng.bjx.com.cn" target="_blank">储能网</a></dd>
                        <dd><a href="http://dianjian.bjx.com.cn" target="_blank">电力建设网</a></dd>
                        <dd><a href="http://nongdian.bjx.com.cn" target="_blank">农电网</a></dd>
                        <dd><a href="http://anfang.bjx.com.cn" target="_blank">电力安防网</a></dd>
                        <dd><a href="http://shupeidian.bjx.com.cn/dltx/" target="_blank">电力通信网</a></dd>
                    </dl>
                  </li>
                  <li>
                    <h6>产品站</h6>
                    <dl>
                        <dd><a href="http://xinxihua.bjx.com.cn" target="_blank">电力软件网</a></dd>
                        <dd><a href="http://zidonghua.bjx.com.cn" target="_blank">自动化网</a></dd>
                        <dd><a href="http://yibiao.bjx.com.cn" target="_blank">仪器仪表网</a></dd>
                        <dd class="nzqred"><a href="http://shupeidian.bjx.com.cn" target="_blank">输配电网</a></dd>
                        <dd><a href="http://bianyaqi.bjx.com.cn" target="_blank">变压器网</a></dd>
                        <dd><a href="http://kaiguan.bjx.com.cn" target="_blank">开关网</a></dd>
                        <dd><a href="http://dianlan.bjx.com.cn" target="_blank">电线电缆网</a></dd>
                        <dd><a href="http://dianyuan.bjx.com.cn" target="_blank">电源网</a></dd>
                    </dl>
                  </li>
                  <li>
                    <h6>功能站</h6>
                    <dl>
                        <dd class="nzqred"><a href="http://news.bjx.com.cn" target="_blank">电力新闻网</a></dd>
                        <dd><a href="http://market.bjx.com.cn" target="_blank">电力市场网</a></dd>
                        <dd><a href="http://tech.bjx.com.cn" target="_blank">电力技术网</a></dd>
                        <dd><a href="http://download.bjx.com.cn" target="_blank">电力资料下载</a></dd>
                        <dd><a href="http://b2b.bjx.com.cn" target="_blank">电力商务通</a></dd>
                        <dd><a href="http://ex.bjx.com.cn" target="_blank">电力会展网</a></dd>
                        <dd><a href="http://bbs.bjx.com.cn" target="_blank">电力论坛</a></dd>
                    </dl>
                  </li>
                  <li class="nzqkuan2">
                    <h6>招聘站</h6>
                    <dl>
                        <dd><a href="http://hr.bjx.com.cn" target="_blank">电力招聘网</a></dd>
                        <dd><a href="http://hdjob.bjx.com.cn" target="_blank">火电招聘网</a></dd>
                        <dd><a href="http://gfjob.bjx.com.cn" target="_blank">光伏招聘网</a></dd>
                        <dd><a href="http://fdjob.bjx.com.cn" target="_blank">风电招聘网</a></dd>
                        <dd><a href="http://sdjob.bjx.com.cn" target="_blank">水电招聘网</a></dd>
                        <dd><a href="http://hr.bjx.com.cn/topics/topics7.shtml" target="_blank">核电招聘网</a></dd>
                        <dd><a href="http://hbjob.bjx.com.cn" target="_blank">环保招聘网</a></dd>
                        <dd><a href="http://www.dqjob.com.cn" target="_blank">电气招聘网</a></dd>
                        <dd><a href="http://gcjob.bjx.com.cn" target="_blank">工程招聘网</a></dd>
                        <dd><a href="http://www.dqjob.com.cn/cdz" target="_blank">充电桩招聘网</a></dd>
                        <dd><a href="http://www.dqjob.com.cn/chuneng" target="_blank">储能招聘网</a></dd>
                        <dd><a href="http://mtjob.bjx.com.cn" target="_blank">煤炭招聘网</a></dd>
                        <dd class="nzqddwide"><a href="http://hr.bjx.com.cn/topics/topics10.shtml" target="_blank">电力信息化招聘网</a></dd>
                    </dl>
                  </li>
                </ul>
                <div class="clear"></div>
            </div>    </div>
        </div>
</div>
<div class="clear"></div>        <div class="xxhbanner">
        <a href="http://huodian.bjx.com.cn/" class="xxhlogo">
            <img width="214" height="60" src="http://img.mybjx.net/theme/default/images/subsite/hd-logo.jpg?bjx_newlogo_v=20161230" alt="北极星火力发电网"/></a>
        <div class="xxhtlt">火电行业垂直门户网站<p><a onclick="homePage(this)">设为首页</a> | <a target="_self" href="javascript:addBookMarkDetail('北极星火力发电网-火力发电新闻|火力发电技术|火力发电招聘|火力发电设备|火力发电产品|火力发电公司',location.href)">加入收藏</a></p></div>
        <div class="adbanner"><span id="kehusign_huodian_top"></span></div>
    </div>
    <div class="hdnav">
        <ul class="hdnavlv1">
            <li class="navf libg" id="menuItem_500"><a target="_self" href="http://huodian.bjx.com.cn/">网站首页</a></li>
            <li id="menuItemM_684"><a target="_self" href="http://huodian.bjx.com.cn/hdcy/">火电产业</a></li>
            <li id="menuItemM_103"><a target="_self" href="http://huodian.bjx.com.cn/hdxm/">火电项目</a></li>
            <li id="menuItemM_496"><a target="_self" href="http://huodian.bjx.com.cn/hdyx/">火电运行</a></li>
            <li id="menuItemM_88"><a target="_self" href="http://huodian.bjx.com.cn/hdjs/">火电技术</a></li>
            <li id="menuItemM_685"><a target="_self" href="http://huodian.bjx.com.cn/hdjn/">火电节能</a></li>
            <li id="menuItemM_686"><a target="_self" href="http://huodian.bjx.com.cn/hdhb/">火电环保</a></li>
            <li id="menuItemM_69"><a target="_self" href="http://huodian.bjx.com.cn/swzfd/">生物质发电</a></li>
            <li id="menuItemM_687"><a target="_self" href="http://huodian.bjx.com.cn/mqny/">煤气能源</a></li>
        </ul>
        <ul class="hdnavlv2">
            <li><a id="menuItemS_yw" target="_self"  href="/NewsList">要闻</a></li>
            <li><a id="menuItemS_89" target="_self" href="/NewsList?id=89">市场</a></li>
            <li><a id="menuItemS_Tech" target="_self" href="/TechList">技术</a></li>
            <li><a id="menuItemS_84" target="_self" href="/NewsList?id=84">人物</a></li>
            <li><a target="_blank" href="http://hdjob.bjx.com.cn/">招聘</a></li>
            <li><a id="menuItemS_76" target="_self" href="/NewsList?id=76">企业</a></li>
            <li><a id="menuItemS_100" target="_self" href="/NewsList?id=100">政策</a></li>
            <li><a id="menuItemS_71" target="_self" href="/NewsList?id=71">评论</a></li>
            <li><a id="menuItemS_120" target="_self" href="/NewsList?id=120">报道</a></li>
            <li><a id="menuItemS_110" target="_self" href="/NewsList?id=110">会展</a></li>
       
            <li class="lip">
              <form id="frmSearch" name="frmSearch" method="post" target="_blank">
                <p class="btndx"><input type="radio"  id="rdoNews" name="rdoCat" value="news" checked="checked"/>新闻</p>
                <p class="btndx"><input type="radio"  id="rdoCom" name="rdoCat" value="company"/>企业</p>
                <p class="btndx"><input type="radio"  id="rdoPro" name="rdoCat" value="product"/>产品</p>
                <p><input type="text" value="输入关键字进行搜索" maxlength="20" onfocus="if(this.value=='输入关键字进行搜索')this.value=''" onblur="if(this.value=='')this.value='输入关键字进行搜索'" size="24" class="txt" id="txtkeyword" name="txtkeyword"/></p>
                <p><input type="button" class="btn" value="搜索" id="btnsearch" name="btnsearch" onclick="searchkeyword() " /> </p>
             </form>
            </li>
        </ul>
    </div>
        <div class="navad">
            <span id="kehusign_huodian_nav_left"></span><span class="navadr" id="kehusign_huodian_nav_right"></span>
        </div>
        <!--行业知识-->
                <div class="newsroll2013">
<h2>行业知识</h2>
<div class="gfnfl">
<a target="_blank" href="http://news.bjx.com.cn/html/20140903/543406.shtml">全球十大火电厂</a> | <a target="_blank" href="http://news.bjx.com.cn/html/20151204/688122.shtml">中国十大火电厂</a>  | <a target="_blank" href="http://news.bjx.com.cn/html/20150918/664864-3.shtml">火电烟气脱硝提供商20强</a> | <a target="_blank" href="http://news.bjx.com.cn/html/20150918/664864.shtml">火电烟气除尘提供商20强</a> | <a target="_blank" href="http://news.bjx.com.cn/html/20150918/664864-2.shtml">火电烟气脱硫提供20强</a>| <a target="_blank" href="http://news.bjx.com.cn/html/20150330/603397.shtml">全国超低排放机组盘点</a>| <a target="_blank" href="http://news.bjx.com.cn/html/20160125/704063.shtml">五大发电装机排行榜</a>
</div>
</div>
<div class="clear"></div>
        <div class="contl_newscorll_box">
            <span class="contl_newsscorll">新闻滚动</span>
            <div class="contl_newsscorll_list">
                <span id="newsS_pre"></span>
                <div class="newsscorll_listbox">
                    <div id="newsScroll" style="width: 878px; overflow: hidden;">
                        <ul class="roll">
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852157.shtml" title="2020天然气发电将超1亿千瓦">2020天然气发电将超1亿千瓦</a></li> 
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852151.shtml" title="垃圾处理应有产业链思维">垃圾处理应有产业链思维</a></li> 
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852136.shtml" title="大唐七台河公司：优胜是这样打造的">大唐七台河公司：优胜是这样打造的</a></li> 
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852125.shtml" title="华能苏州燃机热电联产工程建成投产">华能苏州燃机热电联产工程建成投产</a></li> 
                                <li><a target="_blank" href="http://shupeidian.bjx.com.cn/html/20170925/852104.shtml" title="国网天津电力推动综合能源服务落地">国网天津电力推动综合能源服务落地</a></li> 
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852100.shtml" title="天然气安全存量 拟提高至14天">天然气安全存量 拟提高至14天</a></li> 
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852090.shtml" title="2017年中国火电行业利润率及大面积亏损情况走势分析【图】">2017年中国火电行业利润率及大面积亏损情况走势分析【图】</a></li> 
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852076.shtml" title="山西省57家电厂50家亏损 成本达315.9元/千千瓦时！">山西省57家电厂50家亏损 成本达315.9元/千千瓦时！</a></li> 
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852069.shtml" title="西北四大煤制烯烃项目调研纪要">西北四大煤制烯烃项目调研纪要</a></li> 
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852063.shtml" title="主旨报告丨中国循环流化床锅炉技术的研究开发与应用">主旨报告丨中国循环流化床锅炉技术的研究开发与应用</a></li> 
                        </ul>
                    </div>
                </div>
                <span id="newsS_next"></span>
            </div>
        </div>
        <div class="content_box">
        <div class="content1_left">
        <div class="content1_xu">
            <!--第一部分-->
            <div class="cnt1left">
                <!--第一部分left 开始-->
                <div class="content_left_left_js" id="flashcontent01">
                    <!--第一部分图片新闻 开始-->
                    <script language="javascript" type="text/javascript">
               linkarr = new Array();
               picarr = new Array();
               textarr = new Array();
               var pics = "";
               var mylinks = "";
               var mytexts = "";
               var speed = 4000;        
               var sohuFlash2 = new sohuFlash("http://img.mybjx.net/theme/default/js/common/focus0414a.swf","flashcontent01","300","220","8","#ffffff");
                //这里设置调用标记
linkarr[1] = "http://news.bjx.com.cn/special/?id=851162";picarr[1] = "http://img01.mybjx.net/news/UploadFile/tempNewsImg/201709/20170922112129_5.png";textarr[1] = "深度丨从“煤电联姻”说国企改革";linkarr[2] = "http://news.bjx.com.cn/special/?id=851429";picarr[2] = "http://img01.mybjx.net/news/UploadFile/tempNewsImg/201709/20170922112233_6.png";textarr[2] = "内蒙古1000万千瓦煤电超低排放改造名单";linkarr[3] = "http://news.bjx.com.cn/special/?id=851292";picarr[3] = "http://img01.mybjx.net/news/UploadFile/tempNewsImg/201709/20170922112345_4.png";textarr[3] = "重组在即！国电领导都做了些什么？";linkarr[4] = "http://news.bjx.com.cn/special/?id=850852";picarr[4] = "http://img01.mybjx.net/news/UploadFile/tempNewsImg/201709/20170922112417_2.jpg";textarr[4] = "五彩湾电厂不止你想象的那么美";linkarr[5] = "http://gt.bjx.com.cn/";picarr[5] = "http://img01.mybjx.net/news/UploadFile/tempNewsImg/201708/20170830043732_5.jpg";textarr[5] = "燃机电厂、主机厂商、服务商如何碰出火花？";            //这里设置调用标记
                    
                for(i=1;i<picarr.length;i++){
                if(pics=="") pics = picarr[i];
                else pics += "|"+picarr[i];
                }
                for(i=1;i<linkarr.length;i++){
                if(mylinks=="") mylinks = linkarr[i];
                else mylinks += "|"+linkarr[i];
                }
                for(i=1;i<textarr.length;i++){
                if(mytexts=="") mytexts = textarr[i];
                else mytexts += "|"+textarr[i];
                }
               
               sohuFlash2.addParam("quality", "medium");
               sohuFlash2.addParam("wmode", "opaque");
               sohuFlash2.addVariable("speed",speed);
               sohuFlash2.addVariable("p",pics);    
               sohuFlash2.addVariable("l",mylinks);
               sohuFlash2.addVariable("icon",mytexts);
               sohuFlash2.write("flashcontent01");
                    </script>
                </div>
                <!--第一部分图片新闻 结束-->
                <div class="cnt1lad">
                    <span id="kehusign_huodian_left1"></span>
                </div>
                <!--新闻排行榜 开始-->
                <div class="content1_xwphb hdxwph">
                    <div class="content1_xwphb_top" id="sub_phb_xxk">
                        <p>
                            排行榜</p>
                        <h2 class="content1_xwphb_top_h2" id="subphb1">
                            今日</h2>
                        <h2 class="content1_xwphb_top_h2W" id="subphb2">
                            本周</h2>
                        <h2 class="content1_xwphb_top_h2W" id="subphb3">
                            本月</h2>
                    </div>
                    <div>
                        <div class="content1_xwphb_down" id="con_subphb_1">
                            <ul>
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852004.shtml" title="重磅丨神华集团完成更名 “国家能源集团”诞生！">重磅丨神华集团完成更名 “国家能源集团”诞生！</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852021.shtml" title="重磅丨中电联：2016年度全国CFB机组能效对标及竞赛情况">重磅丨中电联：2016年度全国CFB机组能效对标及竞赛情况</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852063.shtml" title="主旨报告丨中国循环流化床锅炉技术的研究开发与应用">主旨报告丨中国循环流化床锅炉技术的研究开发与应用</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852042.shtml" title="特急文件！山东省纠正不妥行为 保障省直调发电企业正常生产">特急文件！山东省纠正不妥行为 保障省直调发电企业正常生产</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/851998.shtml" title="河北10月底前完成火电机组关停任务">河北10月底前完成火电机组关停任务</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852069.shtml" title="西北四大煤制烯烃项目调研纪要">西北四大煤制烯烃项目调研纪要</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852076.shtml" title="山西省57家电厂50家亏损 成本达315.9元/千千瓦时！">山西省57家电厂50家亏损 成本达315.9元/千千瓦时！</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852090.shtml" title="2017年中国火电行业利润率及大面积亏损情况走势分析【图】">2017年中国火电行业利润率及大面积亏损情况走势分析【图】</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852049.shtml" title="脱硫脱硝行业2016年发展报告：火电脱硫脱硝市场已成为不折不扣的“红海”">脱硫脱硝行业2016年发展报告：火电脱硫脱硝市场已成为不折不扣的“红海”</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852040.shtml" title="江苏省全力压减电煤消耗 1至8月燃煤发电仅增1.12%">江苏省全力压减电煤消耗 1至8月燃煤发电仅增1.12%</a></li> 
                            </ul>
                        </div>
                        <div style="display: none;" class="content1_xwphb_down" id="con_subphb_2">
                            <ul>
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170921/851639.shtml" title="2017中国能源集团500强榜单发布！看看你的企业排第几？（附图解）">2017中国能源集团500强榜单发布！看看你的企业排第几？（附图解）</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170920/851317.shtml" title="《中国煤电清洁发展报告》：煤电清洁发展行动、措施、成效及展望（全文）">《中国煤电清洁发展报告》：煤电清洁发展行动、措施、成效及展望（全文）</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170919/850832.shtml" title="国家能源局“一正四副”配置落定 5位局长最近忙了啥？">国家能源局“一正四副”配置落定 5位局长最近忙了啥？</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170918/850759.shtml" title="重磅丨中电联公布2017年1-8月份电力工业运行简况(图表)">重磅丨中电联公布2017年1-8月份电力工业运行简况(图表)</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170919/851018.shtml" title="河北省“十三五”能源发展规划：大力发展绿色电力  改造提升煤电机组">河北省“十三五”能源发展规划：大力发展绿色电力  改造提升煤电机组</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170920/851292.shtml" title="重组在即！国电集团领导这半年多都做了些什么？">重组在即！国电集团领导这半年多都做了些什么？</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851693.shtml" title="总装机容量最多！华能集团领导如何戴其冠承其重？">总装机容量最多！华能集团领导如何戴其冠承其重？</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170920/851146.shtml" title="特急文件！防止过剩产能死灰复燃！">特急文件！防止过剩产能死灰复燃！</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170921/851473.shtml" title="国家发改委发布关于做好煤电油气运保障工作的通知">国家发改委发布关于做好煤电油气运保障工作的通知</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851865.shtml" title="一周电力项目汇总(9.18-9.22)—核准、开工、并网、环评验收等">一周电力项目汇总(9.18-9.22)—核准、开工、并网、环评验收等</a></li> 
                            </ul>
                        </div>
                        <div style="display: none;" class="content1_xwphb_down" id="con_subphb_3">
                            <ul>
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170916/850439.shtml" title="全文｜江西丰城发电厂“11&#183;24”坍塌特别重大事故调查报告">全文｜江西丰城发电厂“11&#183;24”坍塌特别重大事故调查报告</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170921/851639.shtml" title="2017中国能源集团500强榜单发布！看看你的企业排第几？（附图解）">2017中国能源集团500强榜单发布！看看你的企业排第几？（附图解）</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170911/849000.shtml" title="最新中国企业500强发布：看电力企业谁最赚钱 谁新入围？(附榜单)">最新中国企业500强发布：看电力企业谁最赚钱 谁新入围？(附榜单)</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170906/848108.shtml" title="五大发电集团人均年薪18.22万元！抱歉我拖后腿了">五大发电集团人均年薪18.22万元！抱歉我拖后腿了</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170830/846504.shtml" title="1.8万亿“巨无霸”诞生记丨深度调查这次规模最大的央企大合并 很有意思">1.8万亿“巨无霸”诞生记丨深度调查这次规模最大的央企大合并 很有意思</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170905/847990.shtml" title="独家丨最后一次“五大发电”＋神华集团旗下典型上市公司上半年业绩分析 谁是“赢家”？">独家丨最后一次“五大发电”＋神华集团旗下典型上市公司上半年业绩分析 谁是“赢家”？</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170908/848641.shtml" title="【独家】国家电投2017年1-8月份电力项目汇总：涉及核准、开工、并网等">【独家】国家电投2017年1-8月份电力项目汇总：涉及核准、开工、并网等</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170904/847714.shtml" title="重磅丨中国火电100强名单及燃机、水电、核电排行榜">重磅丨中国火电100强名单及燃机、水电、核电排行榜</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170911/848989.shtml" title="【独家】2017年8月电力项目情况：涉及核准、开工、并网等">【独家】2017年8月电力项目情况：涉及核准、开工、并网等</a></li> 
                                    <li><a target="_blank" href="http://news.bjx.com.cn/html/20170901/847196.shtml" title="广东推进淘汰煤电落后产能：八电厂入围 鼓励提前关停(附文件)">广东推进淘汰煤电落后产能：八电厂入围 鼓励提前关停(附文件)</a></li> 
                            </ul>
                        </div>
                    </div>
                </div>
                <!--新闻排行榜 结束-->
            </div>
            <!--第一部分left 结束-->
            <div class="cnt1main hdyw">
                <!--第一部分main 开始-->
                    <h2 class="yaowen hdyw">
                        <p>
                            要闻聚焦</p>
                        <a  target="_blank" title="神华集团完成更名 “国家能源集团”诞生！" href="http://news.bjx.com.cn/special/?id=852004">神华集团完成更名 “国家能源集团”诞生！</a>
                    </h2>
                    <ul>
                            <li><span></span><a  target="_blank" href="http://news.bjx.com.cn/special/?id=852021" title="中电联：2016全国CFB机组能效对标及竞赛情况">中电联：2016全国CFB机组能效对标及竞赛情况</a></li>
                            <li><span></span><a  target="_blank" href="http://news.bjx.com.cn/special/?id=852090" title="2017中国火电行业利润率及大面积亏损情况分析">2017中国火电行业利润率及大面积亏损情况分析</a></li>
                            <li><span></span><a  target="_blank" href="http://news.bjx.com.cn/special/?id=851947" title="10090亿千瓦时！我国电力消费革命明显提速">10090亿千瓦时！我国电力消费革命明显提速</a></li>
                            <li><span></span><a  target="_blank" href="http://news.bjx.com.cn/special/?id=852042" title="山东发布特急文件！保障省直调发电企业正常生产">山东发布特急文件！保障省直调发电企业正常生产</a></li>
                            <li><span></span><a  target="_blank" href="http://news.bjx.com.cn/special/?id=851429" title="内蒙古：年底前完成1000万千瓦煤电超低排放改造">内蒙古：年底前完成1000万千瓦煤电超低排放改造</a></li>
                            <li><span></span><a  target="_blank" href="http://news.bjx.com.cn/special/?id=852076" title="山西省57家电厂50家亏损 成本达315.9元/千千瓦时！">山西省57家电厂50家亏损 成本达315.9元/千千瓦时！</a></li>
                            <li><span></span><a  target="_blank" href="http://news.bjx.com.cn/special/?id=851804" title="发改委发文：煤企不得以简单停产方式应对执法检查">发改委发文：煤企不得以简单停产方式应对执法检查</a></li>
                    </ul> 
                    <p class="fgline">
                    </p>
                    <ul>
                            <li><a  target="_blank" href="http://news.bjx.com.cn/special/?id=851317" title="《中国煤电清洁发展报告》全文">《中国煤电清洁发展报告》全文</a></li>
                            <li><a  target="_blank" href="http://news.bjx.com.cn/special/?id=850759" title="中电联公布2017年1-8月份电力工业运行简况">中电联公布2017年1-8月份电力工业运行简况</a></li>
                            <li><a  target="_blank" href="http://news.bjx.com.cn/special/?id=850832" title="能源局“一正四副”配置落定 5位局长最近忙了啥？">能源局“一正四副”配置落定 5位局长最近忙了啥？</a></li>
                            <li><a  target="_blank" href="http://news.bjx.com.cn/special/?id=851865" title="独家｜一周电力项目汇总(9.18-9.22)">独家｜一周电力项目汇总(9.18-9.22)</a></li>
                    </ul>
                <div class="hb_dt">
                    <!--第一部分市场动态 开始-->
                    <div class="slide_a">
                        <ul>
                            <li onmouseover="switchSlide('slide_a',1,2);" class="slide_aOff_1" id="slide_a1"><a
                                target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=89">市场动态</a></li>
                            <li onmouseover="switchSlide('slide_a',2,2);" class="slide_aOn_2" id="slide_a2"><a
                                target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=76">名企动态</a></li>
                        </ul>
                        <span id="slide_asp1" class="hb_dtmore" style="display: none;"><a target="_blank"
                            href="http://huodian.bjx.com.cn/NewsList?id=89">&gt;&gt;更多</a></span> <span style=""
                                id="slide_asp2" class="hb_dtmore"><a target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=76">
                                    &gt;&gt;更多</a></span>
                    </div>
                    <div class="slide_abox">
                        <ul id="slide_abox1" style="display: none;">
                                <li><span>09-25</span><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852076.shtml" title="山西省57家电厂50家亏损 成本达315.9元/千千瓦时！">山西省57家电厂50家亏损 成本达315.9元/千千瓦时！</a></li>
                                <li><span>09-25</span><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852058.shtml" title="煤炭市场供需吃紧  有钱也很难拿得到货">煤炭市场供需吃紧  有钱也很难拿得到货</a></li>
                                <li><span>09-22</span><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851944.shtml" title="重磅发布丨2017年上半年煤炭产业报告">重磅发布丨2017年上半年煤炭产业报告</a></li>
                                <li><span>09-22</span><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851859.shtml" title="【2017中国能源集团500强榜单发布】电力行业一周要闻回顾(2017.9.18-9.22)">【2017中国能源集团500强榜单发布】电力行业一周要闻回顾(2017.9.18-9.22)</a></li>
                                <li><span>09-22</span><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851845.shtml" title="【“神电”重组煤电矛盾的“止疼片”】北极星电力网火电一周要闻(2017.9.18-9.22)回顾">【“神电”重组煤电矛盾的“止疼片”】北极星电力网火电一周要闻(2017.9.18-9.22)回顾</a></li>
                                <li><span>09-22</span><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851776.shtml" title="报告全文丨煤电烟气污染控制技术与装备发展报告">报告全文丨煤电烟气污染控制技术与装备发展报告</a></li>
                                <li><span>09-21</span><a target="_blank" href="http://news.bjx.com.cn/html/20170921/851677.shtml" title="[直播]顶级专家团这样说：中国燃气轮机发电市场的挑战与机遇-凡是靠补贴的项目和技术都不会长久">[直播]顶级专家团这样说：中国燃气轮机发电市场的挑战与机遇-凡是靠补贴的项目和技术都不会长久</a></li>
                                <li><span>09-21</span><a target="_blank" href="http://news.bjx.com.cn/html/20170921/851634.shtml" title="煤价大涨再创今年新高 已超红色警戒线恐遭调控">煤价大涨再创今年新高 已超红色警戒线恐遭调控</a></li>
                        </ul>
                        <ul style="" id="slide_abox2">
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852136.shtml" title="大唐七台河公司：优胜是这样打造的">大唐七台河公司：优胜是这样打造的</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852125.shtml" title="华能苏州燃机热电联产工程建成投产">华能苏州燃机热电联产工程建成投产</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852004.shtml" title="重磅丨神华集团完成更名 “国家能源集团”诞生！">重磅丨神华集团完成更名 “国家能源集团”诞生！</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851927.shtml" title="“电亮”三秦大地  跟着赵建国去看看！">“电亮”三秦大地  跟着赵建国去看看！</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851854.shtml" title="[直播]台格尔能源科技高级工程师杨顺虎：燃机电厂的集中控制室必须要有！">[直播]台格尔能源科技高级工程师杨顺虎：燃机电厂的集中控制室必须要有！</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851711.shtml" title="中国华能改革发展成就巡礼：“第一动力”引领绿色发展">中国华能改革发展成就巡礼：“第一动力”引领绿色发展</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851693.shtml" title="总装机容量最多！华能集团领导如何戴其冠承其重？">总装机容量最多！华能集团领导如何戴其冠承其重？</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170921/851654.shtml" title="现场速递:第二届中国燃气轮机论坛2017-业界大咖都在茶歇时间聊些啥？">现场速递:第二届中国燃气轮机论坛2017-业界大咖都在茶歇时间聊些啥？</a></li>
                        </ul>
                    </div>
                </div>
                <!--第一部分市场动态 结束-->
            </div>
            </div>
            <!--第一部分main 结束-->
            <!--第一部分 结束-->
                <!--第二部分 开始-->
                <div class="cnt2left">
                    <!--第二部分left 开始-->
                    <!--第二部分left ad 开始-->
                    <div class="linead1" style="*margin-top:6px;">
                        <span id="kehusign_huodian_banner_left1"></span>
                    </div>
                    <div class="cnt2lline1">
                        <!--第二部分left line1 开始-->
                        <!--火电产业 开始-->
                        <ul class="flmk hblst">
                            <h3>
                                <span><a target="_blank" href="http://huodian.bjx.com.cn/hdcy/">>>更多</a></span>
                                <u><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%u8D85%u4F4E%u6392%u653E">超低排放</a></u>
                                <a
                                    target="_blank" href="http://huodian.bjx.com.cn/hdcy/">火电产业</a></h3>
                                <p class="pbg">
                                    <a  target="_blank" href="http://news.bjx.com.cn/html/20170925/852076.shtml" title="山西省57家电厂50家亏损 成本达315.9元/千千瓦时！" class="linexq">山西省57家电厂50家亏损 成本达315.9元/千千瓦时！</a>
                                    无论是参加电力直接交易的用户，还是围观群众(如媒体记者)，都喜欢在交易时分析发电企业的发... <a  target="_blank" href="http://news.bjx.com.cn/html/20170925/852076.shtml" title="山西省57家电厂50家亏损 成本达315.9元/千千瓦时！" class="flxwxq">
                                        [详情]</a>
                                </p>
                                <li><span>09-25</span><a  target="_blank" title="重磅丨中电联：2016年度全国CFB机组能效对标及竞赛情况" href="http://news.bjx.com.cn/html/20170925/852021.shtml">重磅丨中电联：2016年度全国CFB机组能效对标及竞赛情况</a></li>  
                                <li><span>09-21</span><a  target="_blank" title="[直播]三菱日立电力系统（中国）公司燃机部经理罗磊彬：热电联产的燃机机型应该怎么选？" href="http://news.bjx.com.cn/html/20170921/851629.shtml">[直播]三菱日立电力系统（中国）公司燃机部经理罗磊彬：热电联产的燃机机型应该怎么选？</a></li>  
                                <li><span>09-20</span><a  target="_blank" title="深度报告丨从“煤电联姻”说国企改革" href="http://news.bjx.com.cn/html/20170920/851162.shtml">深度报告丨从“煤电联姻”说国企改革</a></li>  
                                <li><span>09-18</span><a  target="_blank" title="滁州市能源发展“十三五”规划：推进燃煤火电有序发展 布局大型清洁燃煤机组(全文)" href="http://news.bjx.com.cn/html/20170918/850746.shtml">滁州市能源发展“十三五”规划：推进燃煤火电有序发展 布局大型清洁燃煤机组(全文)</a></li>  
                                <li><span>09-18</span><a  target="_blank" title="解局丨陈宗法：国电神华重组 煤电矛盾的“止疼片”" href="http://news.bjx.com.cn/html/20170918/850516.shtml">解局丨陈宗法：国电神华重组 煤电矛盾的“止疼片”</a></li>  
                                <li><span>09-15</span><a  target="_blank" title="深度报告｜电力行业中报总结：火电行业实现扣非净利63.9亿元 同比锐减76%" href="http://news.bjx.com.cn/html/20170915/850278.shtml">深度报告｜电力行业中报总结：火电行业实现扣非净利63.9亿元 同比锐减76%</a></li>  
                                <li><span>09-14</span><a  target="_blank" title="哪些是煤电部门的“落后产能”？" href="http://news.bjx.com.cn/html/20170914/850120.shtml">哪些是煤电部门的“落后产能”？</a></li>  
                                <li><span>09-14</span><a  target="_blank" title="聚焦丨神华集团张熙霖：煤电联营研究及政策建议" href="http://news.bjx.com.cn/html/20170914/849921.shtml">聚焦丨神华集团张熙霖：煤电联营研究及政策建议</a></li>  
                        </ul>
                        <!--火电产业 结束-->
                        <!--火电项目 开始-->
                        <ul class="flmk hblst">
                            <h3 class="fntstl">
                                <span><a target="_blank" href="http://huodian.bjx.com.cn/hdxm/">
                                    >>更多</a></span> <a target="_blank" href="http://huodian.bjx.com.cn/hdxm/">火电项目</a>
                            </h3>
                                <p class="pbg">
                                    <a target="_blank" href="http://news.bjx.com.cn/html/20170925/852069.shtml" title="西北四大煤制烯烃项目调研纪要" class="linexq">西北四大煤制烯烃项目调研纪要</a>
                                    9月4日-9月8日，在大商所和中国石化联合会的组织下调研了西北多家煤化工企业，包括：神华榆... <a target="_blank" href="http://news.bjx.com.cn/html/20170925/852069.shtml" title="西北四大煤制烯烃项目调研纪要" class="flxwxq">
                                        [详情]</a>
                                </p>
                                <li><span>09-22</span><a target="_blank" title="南川页岩气项目本月底输气 年产气将达16亿立方米" href="http://news.bjx.com.cn/html/20170922/851939.shtml">南川页岩气项目本月底输气 年产气将达16亿立方米</a></li>  
                                <li><span>09-22</span><a target="_blank" title="一周核准、中标、开工火电项目汇总(9.18-9.22)——北极星火力发电网" href="http://news.bjx.com.cn/html/20170922/851917.shtml">一周核准、中标、开工火电项目汇总(9.18-9.22)——北极星火力发电网</a></li>  
                                <li><span>09-22</span><a target="_blank" title="一周电力项目汇总(9.18-9.22)—核准、开工、并网、环评验收等" href="http://news.bjx.com.cn/html/20170922/851865.shtml">一周电力项目汇总(9.18-9.22)—核准、开工、并网、环评验收等</a></li>  
                                <li><span>09-21</span><a target="_blank" title="摩洛哥首台350兆瓦超临界空冷燃煤机组并网发电" href="http://news.bjx.com.cn/html/20170921/851615.shtml">摩洛哥首台350兆瓦超临界空冷燃煤机组并网发电</a></li>  
                                <li><span>09-21</span><a target="_blank" title="【项目】近期优质火电项目一览：3个热电项目" href="http://news.bjx.com.cn/html/20170921/851539.shtml">【项目】近期优质火电项目一览：3个热电项目</a></li>  
                                <li><span>09-21</span><a target="_blank" title="投资1.1亿元 马鞍山当涂发电公司发电机组超低排放改造项目全面完成" href="http://news.bjx.com.cn/html/20170921/851463.shtml">投资1.1亿元 马鞍山当涂发电公司发电机组超低排放改造项目全面完成</a></li>  
                                <li><span>09-21</span><a target="_blank" title="总投资3.1亿元 黑龙江逊克县诺宝生物质发电项目正式开工" href="http://news.bjx.com.cn/html/20170921/851458.shtml">总投资3.1亿元 黑龙江逊克县诺宝生物质发电项目正式开工</a></li>  
                                <li><span>09-20</span><a target="_blank" title="项目详情丨上海电建印尼煤电项目、中电顾问国际公司越南燃煤电厂项目" href="http://news.bjx.com.cn/html/20170920/851327.shtml">项目详情丨上海电建印尼煤电项目、中电顾问国际公司越南燃煤电厂项目</a></li>  
                        </ul>
                        <!--火电项目 结束-->
                    </div>
                    <div class="linead">
                        <!--第二部分left ad 开始-->
                        <span id="kehusign_huodian_banner_left2"></span>
                    </div>
                    <!--第二部分left line1 结束-->
                    <div class="cnt2lline1">
                        <!--第二部分left line2 开始-->
                        <!--火电运行 开始-->
                        <ul class="flmk hblst">
                            <h3>
                                <span><a target="_blank" href="http://huodian.bjx.com.cn/hdyx/">>>更多</a></span><a
                                    href="http://huodian.bjx.com.cn/hdyx/">火电运行</a></h3>
                                <p class="pbg">
                                    <a target="_blank" href="http://news.bjx.com.cn/html/20170925/852157.shtml" title="2020天然气发电将超1亿千瓦" class="linexq">2020天然气发电将超1亿千瓦</a>
                                    加快天然气产业发展，提高天然气在一次能源消费中的比重，是我国加快建设清洁低碳、安全高效... <a target="_blank" href="http://news.bjx.com.cn/html/20170925/852157.shtml" title="2020天然气发电将超1亿千瓦" class="flxwxq">
                                        [详情]</a>
                                </p>
                                <li><span>09-25</span><a target="_blank" title="垃圾处理应有产业链思维" href="http://news.bjx.com.cn/html/20170925/852151.shtml">垃圾处理应有产业链思维</a></li>  
                                <li><span>09-25</span><a target="_blank" title="大唐七台河公司：优胜是这样打造的" href="http://news.bjx.com.cn/html/20170925/852136.shtml">大唐七台河公司：优胜是这样打造的</a></li>  
                                <li><span>09-25</span><a target="_blank" title="华能苏州燃机热电联产工程建成投产" href="http://news.bjx.com.cn/html/20170925/852125.shtml">华能苏州燃机热电联产工程建成投产</a></li>  
                                <li><span>09-25</span><a target="_blank" title="天然气安全存量 拟提高至14天" href="http://news.bjx.com.cn/html/20170925/852100.shtml">天然气安全存量 拟提高至14天</a></li>  
                                <li><span>09-25</span><a target="_blank" title="2017年中国火电行业利润率及大面积亏损情况走势分析【图】" href="http://news.bjx.com.cn/html/20170925/852090.shtml">2017年中国火电行业利润率及大面积亏损情况走势分析【图】</a></li>  
                                <li><span>09-25</span><a target="_blank" title="山西省57家电厂50家亏损 成本达315.9元/千千瓦时！" href="http://news.bjx.com.cn/html/20170925/852076.shtml">山西省57家电厂50家亏损 成本达315.9元/千千瓦时！</a></li>  
                                <li><span>09-25</span><a target="_blank" title="西北四大煤制烯烃项目调研纪要" href="http://news.bjx.com.cn/html/20170925/852069.shtml">西北四大煤制烯烃项目调研纪要</a></li>  
                                <li><span>09-25</span><a target="_blank" title="主旨报告丨中国循环流化床锅炉技术的研究开发与应用" href="http://news.bjx.com.cn/html/20170925/852063.shtml">主旨报告丨中国循环流化床锅炉技术的研究开发与应用</a></li>  
                        </ul>
                        <!--火电运行 结束-->
                        <!--火电技术 开始-->
                        <ul class="flmk hblst">
                            <h3 class="fntstl">
                                <span><a target="_blank" href="http://huodian.bjx.com.cn/hdjs/">>>更多</a></span><a
                                    target="_blank" href="http://huodian.bjx.com.cn/hdjs/">火电技术</a></h3>
                                <p class="pbg">
                                    <a target="_blank" href="http://news.bjx.com.cn/html/20170925/852063.shtml" title="主旨报告丨中国循环流化床锅炉技术的研究开发与应用" class="linexq">主旨报告丨中国循环流化床锅炉技术的研究开发与应用</a>
                                    中国循环流化床锅炉技术的研究开发与应用(文章来源：微信公众号循环流化床发电ID：xhlhcfd相... <a target="_blank" href="http://news.bjx.com.cn/html/20170925/852063.shtml" title="主旨报告丨中国循环流化床锅炉技术的研究开发与应用" class="flxwxq">
                                        [详情]</a>
                                </p>
                                <li><span>09-22</span><a target="_blank" title="[直播]中科院广州能源研究所节能环保集成技术中心朱冬生教授：燃气电厂烟气回收技术分享" href="http://news.bjx.com.cn/html/20170922/851946.shtml">[直播]中科院广州能源研究所节能环保集成技术中心朱冬生教授：燃气电厂烟气回收技术分享</a></li>  
                                <li><span>09-22</span><a target="_blank" title="[直播]中科院金属研究所激光表面改性课题组组长谢玉江：不同类型燃机叶片修复工艺方法分享" href="http://news.bjx.com.cn/html/20170922/851924.shtml">[直播]中科院金属研究所激光表面改性课题组组长谢玉江：不同类型燃机叶片修复工艺方法分享</a></li>  
                                <li><span>09-22</span><a target="_blank" title="[直播]坤湖化工科技公司技术总监徐体康：案例分享-高温燃气轮机润滑优化技术的难点突破" href="http://news.bjx.com.cn/html/20170922/851921.shtml">[直播]坤湖化工科技公司技术总监徐体康：案例分享-高温燃气轮机润滑优化技术的难点突破</a></li>  
                                <li><span>09-22</span><a target="_blank" title="[直播]梯西艾燃气轮机材料技术公司郑效慈博士：现场多图演示-燃机修复案例与技术分享" href="http://news.bjx.com.cn/html/20170922/851874.shtml">[直播]梯西艾燃气轮机材料技术公司郑效慈博士：现场多图演示-燃机修复案例与技术分享</a></li>  
                                <li><span>09-22</span><a target="_blank" title="干货丨关于电力工业超低排放技术路径的科普贴" href="http://news.bjx.com.cn/html/20170922/851724.shtml">干货丨关于电力工业超低排放技术路径的科普贴</a></li>  
                                <li><span>09-21</span><a target="_blank" title="[直播]华电旗下华瑞燃机服务副总经理周晔：三菱、西门子、GE的燃机机型华瑞基本都可以维修" href="http://news.bjx.com.cn/html/20170921/851651.shtml">[直播]华电旗下华瑞燃机服务副总经理周晔：三菱、西门子、GE的燃机机型华瑞基本都可以维修</a></li>  
                                <li><span>09-21</span><a target="_blank" title="[直播]瑞士RENK-AG设计总工程师Waldburger：实例证明燃机使用真空齿轮箱可带来更大收益" href="http://news.bjx.com.cn/html/20170921/851646.shtml">[直播]瑞士RENK-AG设计总工程师Waldburger：实例证明燃机使用真空齿轮箱可带来更大收益</a></li>  
                                <li><span>09-21</span><a target="_blank" title="[直播]国电环境保护研究院院长刘志坦：燃气电厂不能闭门造车 应对环保要求必须提前做好技术准备" href="http://news.bjx.com.cn/html/20170921/851585.shtml">[直播]国电环境保护研究院院长刘志坦：燃气电厂不能闭门造车 应对环保要求必须提前做好技术准备</a></li>  
                        </ul>
                        <!--火电技术 结束-->
                    </div>
                    <!--第二部分left lin2 结束-->
                    <div class="linead">
                       <span id="kehusign_huodian_banner_left3"></span>
                    </div>
                    <div class="cnt2lline1">
                        <!--第二部分left line3 开始-->
                        <!--火电节能 开始-->
                        <ul class="flmk hblst">
                            <h3>
                                <span><a target="_blank" href="http://huodian.bjx.com.cn/hdjn/">>>更多</a></span>
                                <u><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%u7164%u7535%u8282%u80FD%u51CF%u6392">煤电节能减排</a></u>
                                <a
                                    target="_blank" href="http://huodian.bjx.com.cn/hdjn/">火电节能</a></h3>
                                <p class="pbg">
                                    <a target="_blank" href="http://news.bjx.com.cn/html/20170922/851724.shtml" title="干货丨关于电力工业超低排放技术路径的科普贴" class="linexq">干货丨关于电力工业超低排放技术路径的科普贴</a>
                                    化石燃料清洁利用技术在电力工业中的应用由来已久。在化石燃料燃烧，燃烧气体进入烟囱排出前... <a target="_blank" href="http://news.bjx.com.cn/html/20170922/851724.shtml" title="干货丨关于电力工业超低排放技术路径的科普贴" class="flxwxq">
                                        [详情]</a>
                                </p>
                                <li><span>09-19</span><a target="_blank" title="环保风暴倒逼钢企加码自发电 5000亿低温余能有望变废为宝" href="http://news.bjx.com.cn/html/20170919/850797.shtml">环保风暴倒逼钢企加码自发电 5000亿低温余能有望变废为宝</a></li>  
                                <li><span>09-18</span><a target="_blank" title="干货丨CFB锅炉燃烧控制策略的实践性探索" href="http://news.bjx.com.cn/html/20170918/850613.shtml">干货丨CFB锅炉燃烧控制策略的实践性探索</a></li>  
                                <li><span>09-15</span><a target="_blank" title="350MW超临界循环流化床机组协调控制策略设计与应用" href="http://news.bjx.com.cn/html/20170915/850224.shtml">350MW超临界循环流化床机组协调控制策略设计与应用</a></li>  
                                <li><span>09-12</span><a target="_blank" title="湖北省发改委公布关于公安县杨家厂镇工业园热电联产项目的节能审查意见" href="http://news.bjx.com.cn/html/20170912/849551.shtml">湖北省发改委公布关于公安县杨家厂镇工业园热电联产项目的节能审查意见</a></li>  
                                <li><span>09-12</span><a target="_blank" title="重庆首个智慧热电联产系统投入使用" href="http://news.bjx.com.cn/html/20170912/849487.shtml">重庆首个智慧热电联产系统投入使用</a></li>  
                                <li><span>09-12</span><a target="_blank" title="《河南省煤电机组节能环保标杆引领行动实施方案》印发" href="http://news.bjx.com.cn/html/20170912/849465.shtml">《河南省煤电机组节能环保标杆引领行动实施方案》印发</a></li>  
                                <li><span>09-07</span><a target="_blank" title="总投资约10亿元 西安高陵垃圾焚烧热电联产项目启动资格预审" href="http://news.bjx.com.cn/html/20170907/848515.shtml">总投资约10亿元 西安高陵垃圾焚烧热电联产项目启动资格预审</a></li>  
                                <li><span>09-05</span><a target="_blank" title="世界最大火力发电厂用科技创新推动节能减排" href="http://news.bjx.com.cn/html/20170905/847797.shtml">世界最大火力发电厂用科技创新推动节能减排</a></li>  
                        </ul>
                        <!--火电节能  结束-->
                        <!--火电环保 开始-->
                        <ul class="flmk hblst">
                            <h3 class="fntstl">
                                <span><a target="_blank" href="http://huodian.bjx.com.cn/hdhb/">>>更多</a></span>
                                <u><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%u7B2C%u4E09%u65B9%u6CBB%u7406">第三方治理</a></u>
                                <a
                                    target="_blank" href="http://huodian.bjx.com.cn/hdhb/">火电环保</a>
                            </h3>
                                <p class="pbg">
                                    <a target="_blank" href="http://news.bjx.com.cn/html/20170925/852049.shtml" title="脱硫脱硝行业2016年发展报告：火电脱硫脱硝市场已成为不折不扣的“红海”" class="linexq">脱硫脱硝行业2016年发展报告：火电脱硫脱硝市场已成为不折不扣的“红海”</a>
                                    中国环保产业协会日前发布《脱硫脱硝行业2016年发展报告》，报告显示：★随着超低排放改造在... <a target="_blank" href="http://news.bjx.com.cn/html/20170925/852049.shtml" title="脱硫脱硝行业2016年发展报告：火电脱硫脱硝市场已成为不折不扣的“红海”" class="flxwxq">
                                        [详情]</a>
                                </p>
                                <li><span>09-22</span><a target="_blank" title="报告全文丨煤电烟气污染控制技术与装备发展报告" href="http://news.bjx.com.cn/html/20170922/851776.shtml">报告全文丨煤电烟气污染控制技术与装备发展报告</a></li>  
                                <li><span>09-22</span><a target="_blank" title="干货丨关于电力工业超低排放技术路径的科普贴" href="http://news.bjx.com.cn/html/20170922/851724.shtml">干货丨关于电力工业超低排放技术路径的科普贴</a></li>  
                                <li><span>09-21</span><a target="_blank" title="[直播]国电环境保护研究院院长刘志坦：燃气电厂不能闭门造车 应对环保要求必须提前做好技术准备" href="http://news.bjx.com.cn/html/20170921/851585.shtml">[直播]国电环境保护研究院院长刘志坦：燃气电厂不能闭门造车 应对环保要求必须提前做好技术准备</a></li>  
                                <li><span>09-21</span><a target="_blank" title="排放标准“世界最严”！我国煤电灵活性改造护航新能源大发展" href="http://news.bjx.com.cn/html/20170921/851490.shtml">排放标准“世界最严”！我国煤电灵活性改造护航新能源大发展</a></li>  
                                <li><span>09-21</span><a target="_blank" title="内蒙古：年底前完成1000万千瓦燃煤机组超低排放改造（附名单）" href="http://news.bjx.com.cn/html/20170921/851429.shtml">内蒙古：年底前完成1000万千瓦燃煤机组超低排放改造（附名单）</a></li>  
                                <li><span>09-20</span><a target="_blank" title="《中国煤电清洁发展报告》：煤电清洁发展行动、措施、成效及展望（全文）" href="http://news.bjx.com.cn/html/20170920/851317.shtml">《中国煤电清洁发展报告》：煤电清洁发展行动、措施、成效及展望（全文）</a></li>  
                                <li><span>09-20</span><a target="_blank" title="从填埋到发电 大辛垃圾场的“前世今生”" href="http://news.bjx.com.cn/html/20170920/851125.shtml">从填埋到发电 大辛垃圾场的“前世今生”</a></li>  
                                <li><span>09-20</span><a target="_blank" title="二维码上岗河北40家火电企业主要排放口：快速查询排污信息" href="http://news.bjx.com.cn/html/20170920/851119.shtml">二维码上岗河北40家火电企业主要排放口：快速查询排污信息</a></li>  
                        </ul>
                        <!--火电环保  结束-->
                    </div>
                    <!--第二部分left lin3 结束-->
                    <div class="linead">
                        <span id="kehusign_huodian_banner_left4"></span>
                    </div>
                    <div class="cnt2lline2">
                        <!--第二部分left line4 开始-->
                        <!--生物质发电 结束-->
                        <ul class="flmk hblst">
                            <h3 class="fntstl">
                                <span><a target="_blank" href="http://huodian.bjx.com.cn/swzfd/">>>更多</a></span><a
                                    target="_blank" href="http://huodian.bjx.com.cn/swzfd/">生物质发电</a>
                            </h3>
                                <p class="pbg">
                                    <a  target="_blank"href="http://news.bjx.com.cn/html/20170922/851917.shtml" title="一周核准、中标、开工火电项目汇总(9.18-9.22)——北极星火力发电网" class="linexq">一周核准、中标、开工火电项目汇总(9.18-9.22)——北极星火力发电网</a>
                                    北极星火力发电网整理了2017年9月18日-2017年9月22日一周火电项目：涉及开工、并网、环评验...
                                    <a target="_blank" href="http://news.bjx.com.cn/html/20170922/851917.shtml" title="一周核准、中标、开工火电项目汇总(9.18-9.22)——北极星火力发电网" class="flxwxq">
                                        [详情]</a>
                                </p>
                                <li><span>09-21</span><a target="_blank" title="总投资3.1亿元 黑龙江逊克县诺宝生物质发电项目正式开工" href="http://news.bjx.com.cn/html/20170921/851458.shtml">总投资3.1亿元 黑龙江逊克县诺宝生物质发电项目正式开工</a></li>  
                                <li><span>09-18</span><a target="_blank" title="总投资约4亿元 盛运集团签约阿勒泰地区生活垃圾焚烧发电项目" href="http://news.bjx.com.cn/html/20170918/850731.shtml">总投资约4亿元 盛运集团签约阿勒泰地区生活垃圾焚烧发电项目</a></li>  
                                <li><span>09-16</span><a target="_blank" title="华电集团调研雄安新区起步区：指导雄安分公司垃圾发电项目" href="http://news.bjx.com.cn/html/20170916/850434.shtml">华电集团调研雄安新区起步区：指导雄安分公司垃圾发电项目</a></li>  
                                <li><span>09-15</span><a target="_blank" title="总投资约4亿元 伟明环保拟为江西樟树新建垃圾焚烧发电项目" href="http://news.bjx.com.cn/html/20170915/850198.shtml">总投资约4亿元 伟明环保拟为江西樟树新建垃圾焚烧发电项目</a></li>  
                                <li><span>09-14</span><a target="_blank" title="【图文】丰富多彩的邀请 BIG设计的乌普萨拉电厂" href="http://news.bjx.com.cn/html/20170914/850068.shtml">【图文】丰富多彩的邀请 BIG设计的乌普萨拉电厂</a></li>  
                                <li><span>09-13</span><a target="_blank" title="总投资约31400万元 上海环境投资蒙城县垃圾焚烧发电厂项目" href="http://news.bjx.com.cn/html/20170913/849903.shtml">总投资约31400万元 上海环境投资蒙城县垃圾焚烧发电厂项目</a></li>  
                                <li><span>09-12</span><a target="_blank" title="总投资约2.46亿元 图们市生活垃圾焚烧发电项目开工" href="http://news.bjx.com.cn/html/20170912/849444.shtml">总投资约2.46亿元 图们市生活垃圾焚烧发电项目开工</a></li>  
                                <li><span>09-11</span><a target="_blank" title="【独家】2017年8月电力项目情况：涉及核准、开工、并网等" href="http://news.bjx.com.cn/html/20170911/848989.shtml">【独家】2017年8月电力项目情况：涉及核准、开工、并网等</a></li>  
                        </ul>
                        <!--生物质发电 结束-->
                        <!--煤气能源 开始-->
                        <ul class="flmk hblst">
                            <h3 class="fntstl">
                                <span><a target="_blank" href="http://huodian.bjx.com.cn/mqny/">>>更多</a></span>
                                <u><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%u71C3%u6C14%u8F6E%u673A">燃气轮机</a></u>
                                <a
                                    target="_blank" href="http://huodian.bjx.com.cn/mqny/">煤气能源</a>
                            </h3>
                                <p class="pbg">
                                    <a target="_blank" href="http://news.bjx.com.cn/html/20170922/851944.shtml" title="重磅发布丨2017年上半年煤炭产业报告" class="linexq">重磅发布丨2017年上半年煤炭产业报告</a>
                                    中国环保产业协会日前发布《脱硫脱硝行业2016年发展报告》，报告显示：★随着超低排放改造在... <a href="http://news.bjx.com.cn/html/20170922/851944.shtml" title="重磅发布丨2017年上半年煤炭产业报告" class="flxwxq">
                                        [详情]</a>
                                </p>
                                <li><span>09-22</span><a target="_blank" title="发改委发文：煤企不得以简单停产方式应对执法检查" href="http://news.bjx.com.cn/html/20170922/851804.shtml">发改委发文：煤企不得以简单停产方式应对执法检查</a></li>  
                                <li><span>09-20</span><a target="_blank" title="央企入晋：五大电力能否重组山西七大省属煤企？" href="http://news.bjx.com.cn/html/20170920/851320.shtml">央企入晋：五大电力能否重组山西七大省属煤企？</a></li>  
                                <li><span>09-18</span><a target="_blank" title="2017年中国山西省煤炭行业国企改革情况分析" href="http://news.bjx.com.cn/html/20170918/850700.shtml">2017年中国山西省煤炭行业国企改革情况分析</a></li>  
                                <li><span>09-16</span><a target="_blank" title="神华宁煤攀上煤化工高峰" href="http://news.bjx.com.cn/html/20170916/850436.shtml">神华宁煤攀上煤化工高峰</a></li>  
                                <li><span>09-15</span><a target="_blank" title="投资283亿元 40亿方煤制天然气项目建设启动" href="http://news.bjx.com.cn/html/20170915/850391.shtml">投资283亿元 40亿方煤制天然气项目建设启动</a></li>  
                                <li><span>09-15</span><a target="_blank" title="重大能源变革：中国成页岩气生产“全球三甲”" href="http://news.bjx.com.cn/html/20170915/850345.shtml">重大能源变革：中国成页岩气生产“全球三甲”</a></li>  
                                <li><span>09-14</span><a target="_blank" title="七大煤炭集团负债率高企 13家上市公司有望唱响混改大戏" href="http://news.bjx.com.cn/html/20170914/849933.shtml">七大煤炭集团负债率高企 13家上市公司有望唱响混改大戏</a></li>  
                                <li><span>09-13</span><a target="_blank" title="上市公司半年报：煤企超九成业绩增长" href="http://news.bjx.com.cn/html/20170913/849679.shtml">上市公司半年报：煤企超九成业绩增长</a></li>  
                        </ul>
                        <!--煤气能源 结束-->
                    </div>
                    <div class="linead">
                        <!--第二部分left ad 开始-->
                        <span id="kehusign_huodian_banner_left5"></span>
                    </div>
                    <div class="cnt2lline2" style="*height:306px;">
                        <!--第二部分left line5 开始-->
                        <!--招标采购 开始-->
                        <ul class="flmk hblst">
                            <h3 class="fntstl">
                                <span><a target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=79">>>更多</a></span><a
                                    target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=79">招标采购</a>
                            </h3>
                                <p class="pbg">
                                    <a target="_blank" href="http://news.bjx.com.cn/html/20170823/845239.shtml" title="同煤阳高2&#215;350MW热电厂项目消防站工程施工项目招标公告" class="linexq">同煤阳高2&#215;350MW热电厂项目消防站工程施工项目招标公告</a>
                                    受大同煤矿集团阳高热电有限公司委托，中招国际招标有限公司对同煤阳高2350MW热电厂项目消防... <a target="_blank" href="http://news.bjx.com.cn/html/20170823/845239.shtml" title="同煤阳高2&#215;350MW热电厂项目消防站工程施工项目招标公告" class="flxwxq">
                                        [详情]</a>
                                </p>
                                <li><span>08-11</span><a target="_blank" title="太原东山煤电集团有限公司李家楼煤业、五龙煤业供热设备采购招标公告" href="http://news.bjx.com.cn/html/20170811/842976.shtml">太原东山煤电集团有限公司李家楼煤业、五龙煤业供热设备采购招标公告</a></li>  
                                <li><span>08-08</span><a target="_blank" title="招标丨国家电投集团2017年8月4日招标公告(涉及热电联产等7项)" href="http://news.bjx.com.cn/html/20170808/842125.shtml">招标丨国家电投集团2017年8月4日招标公告(涉及热电联产等7项)</a></li>  
                                <li><span>07-25</span><a target="_blank" title="漳泽发电厂2&#215;100万千瓦“上大压小”改扩建工程第七批辅机设备采购项目招标公告" href="http://news.bjx.com.cn/html/20170725/839158.shtml">漳泽发电厂2&#215;100万千瓦“上大压小”改扩建工程第七批辅机设备采购项目招标公告</a></li>  
                                <li><span>07-20</span><a target="_blank" title="中国能建正在招标的6个电力项目信息" href="http://news.bjx.com.cn/html/20170720/838380.shtml">中国能建正在招标的6个电力项目信息</a></li>  
                                <li><span>06-27</span><a target="_blank" title="中国能建正在招标的7个电力项目信息" href="http://news.bjx.com.cn/html/20170627/833462.shtml">中国能建正在招标的7个电力项目信息</a></li>  
                                <li><span>06-08</span><a target="_blank" title="2017年5月份全国急需采购设备的拟在建电力&amp;#8203;项目" href="http://news.bjx.com.cn/html/20170608/830009.shtml">2017年5月份全国急需采购设备的拟在建电力&amp;#8203;项目</a></li>  
                                <li><span>06-02</span><a target="_blank" title="电厂项目｜2017火(热)电/生物质垃圾发电项目（招标）信息" href="http://news.bjx.com.cn/html/20170602/828940.shtml">电厂项目｜2017火(热)电/生物质垃圾发电项目（招标）信息</a></li>  
                                <li><span>05-27</span><a target="_blank" title="甘肃电投常乐电厂调峰火电项目4&#215;1000MW（1、2号机组）工程建安工程造价咨询招标公告" href="http://news.bjx.com.cn/html/20170527/828047.shtml">甘肃电投常乐电厂调峰火电项目4&#215;1000MW（1、2号机组）工程建安工程造价咨询招标公告</a></li>  
                        </ul>
                        <!--招标采购 结束-->
                        <!--招聘 开始-->
                        <ul class="flmk hblst">
                            <h3 class="fntstl" style="margin-bottom:6px;*margin-bottom:10px;">
                                <span><a target="_blank" href="http://hdjob.bjx.com.cn/">>>更多</a></span><a target="_blank"
                                    href="http://hdjob.bjx.com.cn/">招聘</a>
                            </h3>
                                <li><span>09-25</span><a target="_blank" title="华润电力中西大区航空港、古城、首阳山、焦作招聘公告" href="http://hdjob.bjx.com.cn/html/20170925/463225.shtml">华润电力中西大区航空港、古城、首阳山、焦作招聘公告</a></li>  
                                <li><span>09-25</span><a target="_blank" title=" 陕西能源赵石畔煤电有限公司最新招聘计划" href="http://hdjob.bjx.com.cn/html/20170925/463211.shtml"> 陕西能源赵石畔煤电有限公司最新招聘计划</a></li>  
                                <li><span>09-22</span><a target="_blank" title="华润电力东南分公司温州、泉惠电厂项目热聘公告" href="http://hdjob.bjx.com.cn/html/20170922/462982.shtml">华润电力东南分公司温州、泉惠电厂项目热聘公告</a></li>  
                                <li><span>09-22</span><a target="_blank" title="国企| 郑州公用事业投资发展集团有限公司电厂项目招聘公告" href="http://hdjob.bjx.com.cn/html/20170922/462977.shtml">国企| 郑州公用事业投资发展集团有限公司电厂项目招聘公告</a></li>  
                                <li><span>09-21</span><a target="_blank" title="北京上庄燃气热电有限公司热招信息推荐" href="http://hdjob.bjx.com.cn/html/20170921/462835.shtml">北京上庄燃气热电有限公司热招信息推荐</a></li>  
                                <li><span>09-21</span><a target="_blank" title="【国企】临沂市恒源热力集团有限公司招聘公告" href="http://hdjob.bjx.com.cn/html/20170921/462832.shtml">【国企】临沂市恒源热力集团有限公司招聘公告</a></li>  
                                <li><span>09-20</span><a target="_blank" title="合肥热电集团有限公司人才招聘计划" href="http://hdjob.bjx.com.cn/html/20170920/462664.shtml">合肥热电集团有限公司人才招聘计划</a></li>  
                                <li><span>09-20</span><a target="_blank" title="中铝能源有限公司最新招聘计划" href="http://hdjob.bjx.com.cn/html/20170920/462667.shtml">中铝能源有限公司最新招聘计划</a></li>  
                                <li><span>09-19</span><a target="_blank" title="京能（锡林郭勒）发电有限公司发布最新招聘计划" href="http://hdjob.bjx.com.cn/html/20170919/462560.shtml">京能（锡林郭勒）发电有限公司发布最新招聘计划</a></li>  
                                <li><span>09-19</span><a target="_blank" title="【国企】中海海南发电有限公司热聘信息一览" href="http://hdjob.bjx.com.cn/html/20170919/462553.shtml">【国企】中海海南发电有限公司热聘信息一览</a></li>  
                                <li><span>09-18</span><a target="_blank" title="中国燃气控股有限公司热聘岗位推荐" href="http://hdjob.bjx.com.cn/html/20170918/462419.shtml">中国燃气控股有限公司热聘岗位推荐</a></li>  
                        </ul>
                        <!--招聘 结束-->
                    </div>
                    </div>
                    <div style="clear:both"></div>
                    <!--第二部分left lin4 结束-->
                </div>
                <div class="content_right_xu">
                            <div class="cnt1r">
                <!--第一部分right 结束-->
                <div class="rightad">
                    <span id="kehusign_huodian_right1"></span>
                </div>
                <div class="rightad">
                    <span id="kehusign_huodian_right2"></span>
                </div>
                <div class="rightad">
                     <span id="kehusign_huodian_right3"></span>
                </div>
                <div class="rightad">
                <span id="kehusign_huodian_right3_1"></span>
                </div>
                <div class="rightad">
                 <span id="kehusign_huodian_right3_2"></span>
<!--                  <a href="http://mti.bjx.com.cn/kehuclick.ashx?id=5558&ref=huodian.bjx.com.cn" title="赛摩电气股份有限公司" target="_blank">
<img width="250" height="60" border="0" src="http://img02.bjx.com.cn/upadimage/201503/2015341613673499.gif">
</a>-->
                </div>
                <div class="clear">
                </div>
                            <div class="fd_ztzl">
 <div class="ztzl_tit">火电最新专题专栏</div>
 <ul>
<li><a href="http://huodian.bjx.com.cn/live/2017mdqj/"><img width="49" alt="中国煤电清洁发展与环境影响发布研讨会" src="http://img.mybjx.net/theme/default/images/www/img_others/2017md.jpg"></a><a class="ztlnk" href="http://huodian.bjx.com.cn/live/2017mdqj/">中国煤电清洁发展与环境影响发布研讨会</a></li> 
 <li><a href="http://news.bjx.com.cn/zhuanti/2017lhxgz/"><img width="49" alt="火电灵活性改造技术研讨会" src="http://img.mybjx.net/theme/default/images/www/img_others/lhxgz.jpg"></a><a class="ztlnk" href="http://news.bjx.com.cn/zhuanti/2017lhxgz/">火电灵活性改造技术研讨会</a></li>
<li><a href="http://gt.bjx.com.cn/"><img width="49" alt="中国燃气轮机论坛2017" src="/content/images/hdimages/zt/rqlj.jpg"></a><a class="ztlnk" href="http://gt.bjx.com.cn/">中国燃气轮机论坛2017</a></li>
 <li style="line-height:14px"><a href="http://news.bjx.com.cn/zhuanti/qxhj/"><img width="49" alt="首个通过国家级环评的单塔一体化技术路线超低排放电厂——大唐集团云冈热电" src="http://img.mybjx.net/theme/default/images/www/img_others/qxhj.jpg"></a><a class="ztlnk" href="http://news.bjx.com.cn/zhuanti/qxhj/">首个通过国家级环评的单塔一体化技术路线超低排放电厂——大唐集团云冈热电</a></li> 
 
 <li><a href="http://news.bjx.com.cn/zhuanti/2015hdcn/"><img width="49" alt="逆势装机 火电很“上火”" src="/content/images/hdimages/zt/1.gif"></a><a class="ztlnk" href="http://news.bjx.com.cn/zhuanti/2015hdcn/">逆势装机 火电很“上火”</a></li> 

</ul></div>
                <!--第一部分right 结束-->
            </div>
                <div class="cnt2right">
                    
                    <div class="clear">
                    </div>
                    <!--第二部分right 评论 人物 结束-->
                    <div class="cnt2rline1">
                        <!--第二部分right 项目 报道 开始-->
                        <p class="cnt2rtlt">
                            <a target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=100">
                                政策</a><span><a target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=100">更多</a></span></p>
                        <ul class="cnt2rlist">
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852042.shtml" title="特急文件！山东省纠正不妥行为 保障省直调发电企业正常生产">特急文件！山东省纠正不妥行为 保障省直调发电企业正常生产</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170921/851473.shtml" title="国家发改委发布关于做好煤电油气运保障工作的通知">国家发改委发布关于做好煤电油气运保障工作的通知</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170921/851429.shtml" title="内蒙古：年底前完成1000万千瓦燃煤机组超低排放改造（附名单）">内蒙古：年底前完成1000万千瓦燃煤机组超低排放改造（附名单）</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170919/851018.shtml" title="河北省“十三五”能源发展规划：大力发展绿色电力  改造提升煤电机组">河北省“十三五”能源发展规划：大力发展绿色电力  改造提升煤电机组</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170918/850746.shtml" title="滁州市能源发展“十三五”规划：推进燃煤火电有序发展 布局大型清洁燃煤机组(全文)">滁州市能源发展“十三五”规划：推进燃煤火电有序发展 布局大型清洁燃煤机组(全文)</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170918/850608.shtml" title="关于印发《河北省淘汰关停煤电机组容量有偿使用暂行办法》的通知">关于印发《河北省淘汰关停煤电机组容量有偿使用暂行办法》的通知</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170915/850182.shtml" title="重磅｜四部门联合推进北方冬季清洁取暖试点工作 未来3年财政将投约697亿元（全文）">重磅｜四部门联合推进北方冬季清洁取暖试点工作 未来3年财政将投约697亿元（全文）</a></li>
                        </ul>
                    </div>
                    <div class="cnt2rline1">
                        <!--第二部分right 项目 报道 开始-->
                        <p class="cnt2rtlt subtlt">
                            <a target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=111">数据</a><span><a target="_blank"
                                href="http://huodian.bjx.com.cn/NewsList?id=111">更多</a></span></p>
                        <ul class="cnt2rlist">
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852090.shtml" title="2017年中国火电行业利润率及大面积亏损情况走势分析【图】">2017年中国火电行业利润率及大面积亏损情况走势分析【图】</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852049.shtml" title="脱硫脱硝行业2016年发展报告：火电脱硫脱硝市场已成为不折不扣的“红海”">脱硫脱硝行业2016年发展报告：火电脱硫脱硝市场已成为不折不扣的“红海”</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852021.shtml" title="重磅丨中电联：2016年度全国CFB机组能效对标及竞赛情况">重磅丨中电联：2016年度全国CFB机组能效对标及竞赛情况</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851949.shtml" title="安全数据报告丨2017年1-8月份全国电力行业触电事故明显降低">安全数据报告丨2017年1-8月份全国电力行业触电事故明显降低</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851947.shtml" title="10090亿千瓦时！我国电力消费革命明显提速">10090亿千瓦时！我国电力消费革命明显提速</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851789.shtml" title="国际电力数据：欧洲OECD国家月度发电量恢复增长">国际电力数据：欧洲OECD国家月度发电量恢复增长</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170922/851743.shtml" title="姜超：发电耗煤虚高">姜超：发电耗煤虚高</a></li>
                        </ul>
                    </div>
                    <!--第二部分right 项目 报道 结束-->
                    <div class="cnt2rline1">
                        <!--第二部分right 政策 管理 开始-->
                        <p class="cnt2rtlt subtlt">
                            <a href="http://huodian.bjx.com.cn/NewsList?id=120">报道</a><span><a target="_blank"
                                href="http://huodian.bjx.com.cn/NewsList?id=120">更多</a></span></p>
                        <ul class="cnt2rlist">
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852157.shtml" title="2020天然气发电将超1亿千瓦">2020天然气发电将超1亿千瓦</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852151.shtml" title="垃圾处理应有产业链思维">垃圾处理应有产业链思维</a></li>
                                <li><a target="_blank" href="http://shupeidian.bjx.com.cn/html/20170925/852104.shtml" title="国网天津电力推动综合能源服务落地">国网天津电力推动综合能源服务落地</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852100.shtml" title="天然气安全存量 拟提高至14天">天然气安全存量 拟提高至14天</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/852040.shtml" title="江苏省全力压减电煤消耗 1至8月燃煤发电仅增1.12%">江苏省全力压减电煤消耗 1至8月燃煤发电仅增1.12%</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170925/851998.shtml" title="河北10月底前完成火电机组关停任务">河北10月底前完成火电机组关停任务</a></li>
                        </ul>
                    </div>
                    <div class="cnt2rad">
                        <span id="kehusign_huodian_right5"></span>
                    </div>
                    <div class="cnt2rline1 lineh3">
                        <!--第二部分right 技术 开始-->
                        <p class="cnt2rtlt">
                            <span class="span_a_xu"><a target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=84">人物</a><b style="float:left; font-weight:normal">/</b><a target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=121">访谈</a></span></p>
                            <h4>
                                <a target="_blank" href="http://news.bjx.com.cn/html/20170921/851518.shtml" title="李鹏飞:发电量增速回落无需过分担忧 中国经济依然强劲">李鹏飞:发电量增速回落无需过分担忧 中国经济依然强劲</a></h4>
                            <p class="cnt2rhxj">
                                9月14日，国家统计局发布的8月份能源生产情况显示，电... <a target="_blank" href="http://news.bjx.com.cn/html/20170921/851518.shtml"
                                    title="李鹏飞:发电量增速回落无需过分担忧 中国经济依然强劲">[详情]</a></p>
                        <div class="clear">
                        </div>
                            <ul class="cnt2rlist">
                                    <li><a target="_blank" title="中电联王志轩：煤电在电力转型过程中发挥着不可替代的作用" href="http://news.bjx.com.cn/html/20170919/851035.shtml">
                                        中电联王志轩：煤电在电力转型过程中发挥着不可替代的作用</a></li>
                                    <li><a target="_blank" title="环保部大气司司长刘炳江：我国将建成世界上最大的清洁高效煤电体系" href="http://news.bjx.com.cn/html/20170919/851027.shtml">
                                        环保部大气司司长刘炳江：我国将建成世界上最大的清洁高效煤电体系</a></li>
                                    <li><a target="_blank" title="解局丨陈宗法：国电神华重组 煤电矛盾的“止疼片”" href="http://news.bjx.com.cn/html/20170918/850516.shtml">
                                        解局丨陈宗法：国电神华重组 煤电矛盾的“止疼片”</a></li>
                                    <li><a target="_blank" title="国家能源局原局长张国宝谈中国天然气的发展之路" href="http://news.bjx.com.cn/html/20170915/850281.shtml">
                                        国家能源局原局长张国宝谈中国天然气的发展之路</a></li>
                                    <li><a target="_blank" title="中国500强企业高峰论坛上 大唐董事长说了什么？" href="http://news.bjx.com.cn/html/20170913/849671.shtml">
                                        中国500强企业高峰论坛上 大唐董事长说了什么？</a></li>
                            </ul>
                    </div>
                    <div class="cnt2rline1">
                        <!--第二部分right 综合资讯 开始-->
                        <p class="cnt2rtlt">
                            <a target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=71"
                                class="more_xu01">评论</a><span><a target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=71">更多</a></span></p>
                        <ul class="cnt2rlist hdlist1">
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170921/851452.shtml" title="煤电去产能紧锣密鼓 合同、费用、就业都是事儿">煤电去产能紧锣密鼓 合同、费用、就业都是事儿</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170916/850441.shtml" title="解读｜同比增长6.4%！8月份全社会用电量情况分析">解读｜同比增长6.4%！8月份全社会用电量情况分析</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170915/850401.shtml" title="国家“点名”山西！又一个天然气大省即将诞生">国家“点名”山西！又一个天然气大省即将诞生</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170913/849687.shtml" title="国家电投张春杨：刍议煤电运营困境如何化解">国家电投张春杨：刍议煤电运营困境如何化解</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170912/849494.shtml" title="聚焦丨朱法华：煤电湿法脱硫是治霾功臣">聚焦丨朱法华：煤电湿法脱硫是治霾功臣</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20170911/849278.shtml" title="谢国兴：煤电发展需自救与他救并举">谢国兴：煤电发展需自救与他救并举</a></li>
                        </ul>
                    </div>
                    <div class="cnt2rad">
                      <span id="kehusign_huodian_right6"></span>
                    </div>
                    <div class="cnt2rline1 lineh3">
                        <!--第二部分right 技术 开始-->
                        <p class="cnt2rtlt">
                            <a target="_blank" class="more_xu01" href="http://huodian.bjx.com.cn/TechList">技术文章</a><span><a
                                href="http://huodian.bjx.com.cn/TechList">更多</a></span></p>
                            <h4>
                                <a target="_blank" title="PH计电极球泡碎了怎么办？" href="http://b2b.bjx.com.cn/8435125/tech-155060.html">
                                    PH计电极球泡碎了怎么办？</a></h4>
                            <p class="cnt2rhxj">
                                pH电极又称pH探头、pH传感器，英文名称pHelectrode或p... <a target="_blank" title="PH计电极球泡碎了怎么办？" href="http://b2b.bjx.com.cn/8435125/tech-155060.html">
                                    [详情]</a></p>
                        <div class="clear">
                        </div>
                            <ul class="cnt2rlist">
                                    <li><a target="_blank" href="http://b2b.bjx.com.cn/8435125/tech-154656.html" title="PH计的正确使用与维护">
                                        PH计的正确使用与维护</a></li>
                                    <li><a target="_blank" href="http://b2b.bjx.com.cn/8435125/tech-153607.html" title="气体分析仪在气调库上的应用">
                                        气体分析仪在气调库上的应用</a></li>
                                    <li><a target="_blank" href="http://b2b.bjx.com.cn/8435125/tech-153460.html" title="压力表量程选择和型式选择的技巧">
                                        压力表量程选择和型式选择的技巧</a></li>
                                    <li><a target="_blank" href="http://b2b.bjx.com.cn/8435125/tech-153373.html" title="电子称维修知识">
                                        电子称维修知识</a></li>
                                    <li><a target="_blank" href="http://b2b.bjx.com.cn/8435125/tech-153369.html" title="什么是无纸记录仪">
                                        什么是无纸记录仪</a></li>
                            </ul>
                    </div>
                    <div class="cnt2rline1" style="margin-top: 9px;margin-bottom:0px;">
                        <!--第二部分right 企业推荐 开始-->
                        <p class="cnt2rtlt">
                            <a href="http://huodian.bjx.com.cn/NewsList?id=110" target="_blank"
                                class="more_xu01">会展</a><span><a target="_blank" href="http://huodian.bjx.com.cn/NewsList?id=110">更多</a></span></p>
                        <ul class="cnt2rlist">
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20150428/612679.shtml" title="举办全国电厂燃煤节能减排升级改造解决方案经验交流会的通知">举办全国电厂燃煤节能减排升级改造解决方案经验交流会的通知</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20150320/600029.shtml" title="中国电建携手西门子成功举办中国电力EPC论坛">中国电建携手西门子成功举办中国电力EPC论坛</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20150319/599792.shtml" title="燃煤电厂除尘技术交流会在宁波举行">燃煤电厂除尘技术交流会在宁波举行</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20150211/589979.shtml" title="2015中国燃气轮机聚焦6月与您见面">2015中国燃气轮机聚焦6月与您见面</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20150206/588716.shtml" title="2015中国能源互联网高峰论坛 暨中国能源互联网联盟成立揭牌仪式">2015中国能源互联网高峰论坛 暨中国能源互联网联盟成立揭牌仪式</a></li>
                                <li><a target="_blank" href="http://news.bjx.com.cn/html/20150128/585891.shtml" title="【在线研讨会】雷泰红外测温仪在火电行业的应用">【在线研讨会】雷泰红外测温仪在火电行业的应用</a></li>
                        </ul>
                    </div>
                </div>
                <!--第二部分right 结束-->
            </div>
              </div>
             <div style="*height:8px"></div>
            <!--第二部分 结束-->
            <div class="hotword">
    <span>热搜词 -</span>
    <ul><li><a class="red" target="_blank" href="http://news.bjx.com.cn/zhuanti/2017lhxgz/">灵活性改造</a></li>
    <li><a class="red" target="_blank" href="http://news.bjx.com.cn/zhuanti/2017rmfh/">清洁燃煤</a></li>
    <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%bb%f0%b5%e7">火电</a></li>
        <li><a class="red" target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%ce%e5%b4%f3%b7%a2%b5%e7">五大发电</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%cb%c4%d0%a1%ba%c0%c3%c5">四小豪门</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%bb%aa%c4%dc">华能</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%b9%fa%b5%e7">国电</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%bb%aa%b5%e7">华电</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%b4%f3%cc%c6">大唐</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%b9%fa%bc%d2%b5%e7%cd%b6
">国家电投</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%c9%f1%bb%aa">神华</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%bb%aa%c8%f3">华润</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%d5%e3%c4%dc">浙能</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%c5%ac%b6%fb%a1%a4%b0%d7%bf%cb%c1%a6">努尔·白克力</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%c0%ee%d0%a1%c1%d5">李小琳</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%cd%f5%d6%be%d0%f9">王志轩</a></li>
        <li><a target="_blank" href="
http://news.bjx.com.cn/zt.asp?topic=%c9%cf%ba%a3%cd%e2%b8%df%c7%c5%b5%da%c8%fd%b7%a2%b5%e7">上海外高桥第三发电</a></li>
        <li><a class="red" target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%b3%ac%b5%cd%c5%c5%b7%c5">超低排放</a></li>  
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%b5%da%c8%fd%b7%bd%d6%ce%c0%ed">第三方治理</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%cd%d1%c1%f2%cd%d1%cf%f5">脱硫脱硝</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%b3%fd%b3%be">除尘</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%d1%cc%c6%f8%d6%ce%c0%ed">烟气治理</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%c8%c8%b5%e7%c1%aa%b2%fa">热电联产</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%c9%cf%b4%f3%d1%b9%d0%a1">上大压小</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%c3%ba%b5%e7%d2%bb%cc%e5%bb%af">煤电一体化</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%c3%ba%b5%e7%c1%aa%b6%af">煤电联动</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%b5%cd%c8%c8%d6%b5%c3%ba%b7%a2%b5%e7">低热值煤发电</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%b7%a2%b5%e7%c1%bf">发电量</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%bb%f0%b5%e7%d7%b0%bb%fa">火电装机</a></li>
        <li><a class="red" target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%bb%f0%b5%e7%cf%ee%c4%bf">火电项目</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%bb%f0%b5%e7%c9%f3%c5%fa">火电审批</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%b6%fe%b4%ce%d4%d9%c8%c8">二次再热</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%bb%b7%b1%a3%b5%e7%bc%db">环保电价</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%c9%cf%cd%f8%b5%e7%bc%db">上网电价</a></li>
        <li class="pad" style="padding:0;"></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%b9%a9%b5%e7%c3%ba%ba%c4">供电煤耗</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%b7%a2%b5%e7%c9%e8%b1%b8">发电设备</a></li>
        <li><a class="red" target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%c8%bc%c6%f8%c2%d6%bb%fa">燃气轮机</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%cc%ec%c8%bb%c6%f8%b7%a2%b5%e7">天然气发电</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%c9%fa%ce%ef%d6%ca%b7%a2%b5%e7">生物质发电</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%c0%ac%bb%f8%b7%d9%c9%d5%b7%a2%b5%e7">垃圾焚烧发电</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%d1%ad%bb%b7%c1%f7%bb%af%b4%b2">循环流化床</a></li>
        <li><a target="_blank" href="http://news.bjx.com.cn/zt.asp?topic=%d6%d8%b5%e3%c4%dc%d4%b4%cf%ee%c4%bf">重点能源项目</a></li>
    </ul>
    
    <div class="clear"></div>
</div>
            <script>
$(document).ready(function(){
    $(".close-ewm").click(function(){
        $(".fd-ewm").hide();
    });
    $(".fd-ewm").hover(function(){
        $(this).css("width","273px");
        $(".close-ewm").css("margin-right","162px");
    },function(){
        $(this).css("width","111px");
        $(".close-ewm").css("margin-right","0");
    })
})
</script>
<div class="fd-ewm">
    <div class="close-ewm"></div>
    <img src="http://img.mybjx.net/theme/default/images/subsite/hd_ewm.jpg?bjx_newlogo_v=20161230" />
    <img src="http://img.mybjx.net/theme/default/images/subsite/hdewm.jpg?bjx_newlogo_v=20161230" class="fd_big_ewm" />
</div>
                <!--会展推荐-->
            <div class="cont_zhtj">
    <div class="contl_right_qyjjtitbg"><span class="contl_right_qyjjtit">会展推荐</span></div>
    <div class="cont_zhtjinner">
        <div class="cont_zhtjinner_list">
            <span id="kehusign_huodian_bottom_hz1"></span>
        </div>
        <div class="cont_zhtjinner_list">
            <span id="kehusign_huodian_bottom_hz2"></span>
        </div>
        <div class="cont_zhtjinner_list">
            <span id="kehusign_huodian_bottom_hz3"></span>
        </div>
        <div class="cont_zhtjinner_list">
            <span id="kehusign_huodian_bottom_hz4"></span>
        </div>
        <div class="cont_zhtjinner_list">
            <span id="kehusign_huodian_bottom_hz5"></span>
        </div>      
    </div>  
</div>
<!--友情链接-->
<div class="cont_tyzndw"> 
    <div class="contl_right_qyjjtitbg">
        <span class="contl_right_qyjjtit hdflink">友情链接</span>
        <div class="contl_right_linkshop">
            <span class="contl_right_sqlink"><a target="_blank" href="http://www.bjx.com.cn/about/lxwm.html#link">申请友情链接:QQ：1109669179</a></span>
            <span class="contl_right_qq"><a target="_blank" href="tencent://message/?uin=1109669179&amp;Site=www.bjx.com.cn&amp;Menu=yes"><img src="http://img.mybjx.net/theme/default/images/common/qq_icon.gif"></a></span>
        </div>
        <div class="clear"></div>
    </div>
    <div class="cont_linkinner">
        <a href="http://www.csgcn.com.cn/" target="_blank">页岩气</a>
        <a href="http://guangfubbs.bjx.com.cn"  target="_blank">光伏论坛</a>
        <a href="http://www.cnmhg.com/" target="_blank">中国煤化工网</a>
        <a href="http://www.duoic.com/" target="_blank">电子元器件采购网</a>
        <a href="http://www.chaiyoufadianjizu.cn/" target="_blank">柴油发电机组</a>
        <a href="http://www.zgbidding.com/" target="_blank">中国招投标信息服务平台</a>
        <a href="http://www.cnpowerbid.com/" target="_blank">中国电力招投标信息网</a>
        <a href="http://www.aeenets.com/" target="_blank">亚欧网</a>
        <div class="clear"></div>
    </div>
</div>
    
            <!--友情链接-->
            <script type="text/javascript" src="http://img.mybjx.net/theme/default/js/common/duilianchn.js"></script>
<!--<div class="zhuanti" id="zhuanti_left">
<div class="adLeft"><span id="kehusign_huodian_dl_left_b"></span><p class="closel">关闭</p></div>
<div class="zt_left"><span id="kehusign_huodian_dl_left_s"></span><p class="replayL">重播</p></div>
</div>-->
<!--<div class="zhuanti" id="zhuanti_right">
<div class="adRight"><span id="kehusign_huodian_dl_right_b"></span><p class="closer">关闭</p></div>
<div class="zt_right"><span id="kehusign_huodian_dl_right_s"></span><p class="replayR">重播</p></div>
</div>-->
            <!--对联-->
            
<div class="cont_copyright"><!--footer-->
   <div class="footer_middle">
    <strong style="float:left; line-height:29px; padding-left:15px">广告服务：</strong><script type="text/javascript" src="http://img.mybjx.net/theme/default/js/common/RandSaleName.js?v=0621" charset='gb2312'></script>
    <span class="LongW">媒体合作/投稿：陈女士 13693626116</span><a href="tencent://message/?uin=1831213786&Site=im.qq.com&Menu=yes"><img align="absmiddle" border="0" alt="点击这里给我发消息" src="http://img.mybjx.net/theme/default/images/common/qq_new.gif"></a>
  </div>
        <p>
<a href="http://www.bjx.com.cn/about/about.html" title="关于北极星">关于北极星</a> | <a href="http://www.bjx.com.cn/about/baojia_index.html" >广告服务</a> | <a href="http://www.bjx.com.cn/about/serv.html" >会员服务</a> | <a href="http://news.bjx.com.cn/list?catid=112" >媒体报道</a> | <a href="http://www.bjx.com.cn/about/yxfa.html" >营销方案</a> | <a href="http://www.bjx.com.cn/about/anli.html" >成功案例</a> | <a href="http://hr.bjx.com.cn/" >招聘服务</a> | <a href="http://hr.bjx.com.cn/2012/" >加入我们</a> | <a href="http://map.bjx.com.cn/" >网站地图</a> | <a href="http://www.bjx.com.cn/about/help.html">在线帮助</a> | <a href="http://www.bjx.com.cn/about/lxwm.html">联系我们</a> | 
<script src='http://w.cnzz.com/c.php?id=30036438&l=3' type="text/javascript"></script><p>版权所有 <font style="font-family:arial">&copy;</font>&nbsp;1999-2017 北极星电力网(Bjx.Com.Cn) 运营：北京火山动力网络技术有限公司 </p>
<p><a href="http://www.hd315.gov.cn/beian/view.asp?bianhao=0102000110800008" rel="nofollow" target="_blank"><img alt="" src="http://img.mybjx.net/theme/default/images/common/jyxwb.gif"/></a><a href="http://img.mybjx.net/theme/default/images/common/icp1.jpg" target="_blank" rel="nofollow"><img alt="" src="http://img.mybjx.net/theme/default/images/common/icpjy.gif"/></a><a rel="nofollow" href="http://net.china.com.cn/" target="_blank"><img alt="" src="http://img.mybjx.net/theme/default/images/common/blxxjb.gif"/></a><a href="http://www.cyberpolice.cn" rel="nofollow" target="_blank"><img alt=""  src="http://img.mybjx.net/theme/default/images/common/wl110.gif" /></a></p><p><a href="http://img.mybjx.net/theme/default/images/common/icp1.jpg" target="_blank" rel="nofollow">京ICP证080169号</a>  <a href="http://www.miibeian.gov.cn/" target="_blank">京ICP备09003304号-2</a>  京公网安备：<a href="http://www.bjgaj.gov.cn/web/" rel="nofollow" target="_blank">1101052752</a><a href="http://www.bjx.com.cn/icp.html" target="_blank">电子公告服务专项备案</a></p>
        </p>
        <p></p>
    <!--统计-->
    <div class="clear"></div>
    <script type="text/javascript">        var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://"); document.write(unescape("%3Cdiv id='cnzz_stat_icon_30081637'%3E%3C/div%3E%3Cscript src='" + cnzz_protocol + "w.cnzz.com/c.php%3Fid%3D30081637%26l%3D2' type='text/javascript'%3E%3C/script%3E"));</script>
    <script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fc32964cdd0907bbd6938f89413c67dee' type='text/javascript'%3E%3C/script%3E"));
</script>
</div>

<!--footer-->
<script src="http://img.mybjx.net/theme/default/js/common/bjxui.js" charset="gbk" type="text/javascript"></script>
<script src="http://img.mybjx.net/theme/default/js/subsite/subsit.js" type="text/javascript" charset="gbk"></script>
<script type="text/javascript" src="http://img.mybjx.net/theme/default/js/common/mtibjx.js"></script>
 

      
</body>
</html>

'''
